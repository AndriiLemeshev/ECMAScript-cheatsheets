/**
 * Represents a value that may or may not be present.  This is a common pattern
 * in functional programming to avoid null or undefined values and handle them
 * gracefully.  Think of it as a container that might hold something, or might
 * be empty.
 */
export class Maybe {
    /**
     * Constructs a new Maybe instance.
     * @param {*} value The value to wrap in the Maybe.  Can be any type, including
     * null or undefined.
     */
    constructor(value) {
      this.value = value;
    }
  
    /**
     * Creates a new Maybe instance containing a value.  Use this for creating
     * Maybes when you *know* you have a value.
     * @param {*} value The value to wrap.
     * @returns {Maybe} A new Maybe instance containing the given value.
     * @example
     * const maybeValue = Maybe.just(42);
     */
    static just(value) {
      return new Maybe(value);
    }
  
    /**
     * Creates a new Maybe instance representing the absence of a value.  Use
     * this when you *don't* have a value, or when an operation might fail.
     * @returns {Maybe} A new Maybe instance representing the absence of a value.
     * @example
     * const emptyMaybe = Maybe.nothing();
     */
    static nothing() {
      return new Maybe(null); // Or undefined.  Using null for consistency.
    }
  
    /**
     * Applies a function to the value inside the Maybe, if a value is present.
     * If the Maybe is empty (contains nothing), it returns an empty Maybe
     * without applying the function.  This allows you to chain operations
     * without worrying about null or undefined values.
     * @param {function} fn The function to apply to the value.  Should accept
     * the value as an argument and return a new value.
     * @returns {Maybe} A new Maybe instance containing the result of applying
     * the function, or an empty Maybe if the original Maybe was empty.
     * @example
     * const maybeValue = Maybe.just(42);
     * const doubled = maybeValue.map(x => x * 2); // doubled will be Maybe.just(84)
     *
     * const emptyMaybe = Maybe.nothing();
     * const mappedEmpty = emptyMaybe.map(x => x * 2); // mappedEmpty will be Maybe.nothing()
     */
    map(fn) {
      if (this.value == null) { // Handling null/undefined
        return Maybe.nothing();
      }
      return Maybe.just(fn(this.value));
    }
  
    /**
     * Returns the value inside the Maybe if it's present.  If the Maybe is
     * empty, it returns the provided default value.  This is a way to extract
     * the value from the Maybe while providing a fallback.
     * @param {*} defaultValue The value to return if the Maybe is empty.
     * @returns {*} The value inside the Maybe, or the default value if the
     * Maybe is empty.
     * @example
     * const maybeValue = Maybe.just(42);
     * const value = maybeValue.getOrElse(0); // value will be 42
     *
     * const emptyMaybe = Maybe.nothing();
     * const emptyValue = emptyMaybe.getOrElse(0); // emptyValue will be 0
     */
    getOrElse(defaultValue) {
      return this.value == null ? defaultValue : this.value;
    }
}
