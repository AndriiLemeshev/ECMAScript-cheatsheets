export const math = {
    add: y => x => x + y,
    sub: y => x => x - y,
    mul: y => x => x * y,
    div: y => x => x / y,
};
