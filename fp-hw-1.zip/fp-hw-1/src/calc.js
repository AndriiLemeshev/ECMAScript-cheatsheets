import { Maybe } from "./maybe.js";
import { math } from "./math.js";

/**
 * Performs a series of mathematical operations on an initial value.
 * The operations are applied sequentially using a functional approach
 * with the `Maybe` monad to handle potential errors (like division by zero).
 *
 * @param {Array<[string, number]>} [operations=[]] An array of operations to perform.
 * Each operation is a tuple (array) where the first element is the name of the
 * operation ('add', 'sub', 'mul', 'div') and the second element is the
 * argument for that operation.
 * @param {number} [initial=0] The initial value to start with.
 *
 * @returns {number} The result of applying all operations to the initial
 * value. Returns `NaN` if any operation results in an invalid number
 * (e.g., division by zero).
 *
 * @example
 * // Performs the following calculations:
 * // 0 + 1 = 1
 * // 1 * 3 = 3
 * // 3 - 2 = 1
 * // 1 / 2 = 0.5
 * // 0.5 + 1 = 1.5
 * const result = calc([
 *   ['add', 1],
 *   ['mul', 3],
 *   ['sub', 2],
 *   ['div', 2],
 *   ['add', 1]
 * ]); // result will be 1.5
 *
 * @example
 * // Example with division by zero:
 * const result2 = calc([
 *   ['div', 0]
 * ], 10); // result2 will be NaN
 */
export function calc(operations = [], initial = 0) {
    return operations.reduce((maybe, [operation, argument]) => maybe.map(math[operation](argument)), Maybe.just(initial)).getOrElse(NaN);
}
