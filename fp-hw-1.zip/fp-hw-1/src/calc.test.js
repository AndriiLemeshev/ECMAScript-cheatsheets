import { calc } from './calc.js';

describe('calc function', () => {
  it('should perform a series of operations correctly', () => {
    const operations = [
      ['add', 1],
      ['mul', 3],
      ['sub', 2],
      ['div', 2],
      ['add', 1],
    ];
    const result = calc(operations, 0);
    expect(result).toBe(1.5);
  });

  it('should handle division by zero and return Infinite', () => {
    const operations = [['div', 0]];
    const result = calc(operations, 10);
    expect(isFinite(result)).toBe(false);
  });

  it('should handle an empty operations array and return the initial value', () => {
    const result = calc([], 5);
    expect(result).toBe(5);
  });

  it('should handle operations with negative numbers', () => {
    const operations = [
      ['add', -5],
      ['mul', -2],
      ['sub', -10],
    ];
    const result = calc(operations, 10);
    expect(result).toBe(0);
  });

    it('should handle operations with floating-point numbers', () => {
        const operations = [
            ['add', 2.5],
            ['mul', 1.5],
            ['sub', 0.5],
        ];
        const result = calc(operations, 1.0);
        expect(result).toBeCloseTo(4.75); // Use toBeCloseTo for floating-point comparisons
    });

    it('should handle a single operation correctly', () => {
        const result = calc([['mul', 5]], 2);
        expect(result).toBe(10);
    });

    it('should use the default initial value of 0 when none is provided', () => {
        const result = calc([['add', 5]]);
        expect(result).toBe(5);
    });

    it('should handle more complex calculations', () => {
        const operations = [
            ['add', 10],
            ['mul', 2],
            ['sub', 5],
            ['div', 5],
            ['add', 1],
            ['mul', 0.5]
        ];
        const result = calc(operations, 5);
        expect(result).toBeCloseTo(3);
    });
});