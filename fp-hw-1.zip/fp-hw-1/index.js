import { calc } from "./src/calc.js";

console.log("result = ", calc([
    ['add', 1],
    ['mul', 3],
    ['sub', 2],
    ['div', 2],
    ['add', 1]
]));
